
$$$$$$$\                                                    
$$  __$$\                                                   
$$ |  $$ | $$$$$$\  $$$$$$$\   $$$$$$\   $$$$$$\  $$\   $$\ 
$$ |  $$ |$$  __$$\ $$  __$$\  \____$$\ $$  __$$\ $$ |  $$ |
$$ |  $$ |$$ /  $$ |$$ |  $$ | $$$$$$$ |$$ |  \__|$$ |  $$ |
$$ |  $$ |$$ |  $$ |$$ |  $$ |$$  __$$ |$$ |      $$ |  $$ |
$$$$$$$  |\$$$$$$  |$$ |  $$ |\$$$$$$$ |$$ |      \$$$$$$  |
\_______/  \______/ \__|  \__| \_______|\__|       \______/ 
                                                            
                                                            
Whatsapp Bulk Group Creator v1.0 (30/4/2018)                                                            

=================================================================================================
This software is for education purposes only to identify the loopholes in the Whatsapp Community.

Please note this version is for Windows Whatsapp Program only
=================================================================================================


Step 1: 
=======
Download the latest Whatsapp Program for Windows

https://web.whatsapp.com/desktop/windows/release/x64/WhatsAppSetup.exe

Step 2: 
=======
Launch Whatsapp and scan QR Code

Step 3: 
=======
Run Generator App

Step 4: 
=======

Fill in the fields and press [Go]

Enjoy!!!